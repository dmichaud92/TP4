from interface.fenetre_principale import FenetrePrincipale

fenetre_principale = FenetrePrincipale()
fenetre_principale.mainloop()
